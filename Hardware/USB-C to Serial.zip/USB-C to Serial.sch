EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title "Serial Expansion Card"
Date "2022-05-04"
Rev "A"
Comp "Josh Cook"
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Connector:USB_C_Plug_USB2.0 P1
U 1 1 61CAD42C
P 1950 1950
F 0 "P1" H 2057 2817 50  0000 C CNN
F 1 "USB_C_Plug_USB2.0" H 2057 2726 50  0000 C CNN
F 2 "Expansion_Card:USB_C_Plug_Molex_105444" H 2100 1950 50  0001 C CNN
F 3 "https://www.usb.org/sites/default/files/documents/usb_type-c.zip" H 2100 1950 50  0001 C CNN
	1    1950 1950
	1    0    0    -1  
$EndComp
$Comp
L Device:R_US R3
U 1 1 61CB02A3
P 4100 2050
F 0 "R3" V 3950 2050 50  0000 C CNN
F 1 "27k" V 3850 2050 50  0000 C CNN
F 2 "Resistor_SMD:R_0402_1005Metric" V 4140 2040 50  0001 C CNN
F 3 "~" H 4100 2050 50  0001 C CNN
	1    4100 2050
	0    -1   -1   0   
$EndComp
$Comp
L Device:R_US R2
U 1 1 61CB1044
P 4100 1850
F 0 "R2" V 3895 1850 50  0000 C CNN
F 1 "27k" V 3986 1850 50  0000 C CNN
F 2 "Resistor_SMD:R_0402_1005Metric" V 4140 1840 50  0001 C CNN
F 3 "~" H 4100 1850 50  0001 C CNN
	1    4100 1850
	0    1    1    0   
$EndComp
$Comp
L Device:R_US R1
U 1 1 61CB2317
P 3250 1550
F 0 "R1" V 3455 1550 50  0000 C CNN
F 1 "5.1K" V 3364 1550 50  0000 C CNN
F 2 "Resistor_SMD:R_0402_1005Metric" V 3290 1540 50  0001 C CNN
F 3 "~" H 3250 1550 50  0001 C CNN
	1    3250 1550
	0    -1   -1   0   
$EndComp
$Comp
L power:Earth #PWR03
U 1 1 61CB2A7B
P 3500 1650
F 0 "#PWR03" H 3500 1400 50  0001 C CNN
F 1 "Earth" H 3500 1500 50  0001 C CNN
F 2 "" H 3500 1650 50  0001 C CNN
F 3 "~" H 3500 1650 50  0001 C CNN
	1    3500 1650
	1    0    0    -1  
$EndComp
Wire Wire Line
	3500 1650 3500 1550
Wire Wire Line
	3500 1550 3400 1550
$Comp
L Device:C C1
U 1 1 61CB30F7
P 2900 2650
F 0 "C1" H 3015 2696 50  0000 L CNN
F 1 "0.1uF" H 3015 2605 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 2938 2500 50  0001 C CNN
F 3 "~" H 2900 2650 50  0001 C CNN
	1    2900 2650
	1    0    0    -1  
$EndComp
$Comp
L Device:C C2
U 1 1 61CB34EF
P 3400 2650
F 0 "C2" H 3515 2696 50  0000 L CNN
F 1 "47pF" H 3515 2605 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 3438 2500 50  0001 C CNN
F 3 "~" H 3400 2650 50  0001 C CNN
	1    3400 2650
	1    0    0    -1  
$EndComp
$Comp
L Device:C C4
U 1 1 61CB388C
P 3750 2650
F 0 "C4" H 3865 2696 50  0000 L CNN
F 1 "47pF" H 3865 2605 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 3788 2500 50  0001 C CNN
F 3 "~" H 3750 2650 50  0001 C CNN
	1    3750 2650
	1    0    0    -1  
$EndComp
Wire Wire Line
	2550 2050 3400 2050
Wire Wire Line
	2550 1850 3750 1850
Wire Wire Line
	3750 2500 3750 1850
Connection ~ 3750 1850
Wire Wire Line
	3750 1850 3950 1850
Wire Wire Line
	3400 2500 3400 2050
Connection ~ 3400 2050
Wire Wire Line
	3400 2050 3950 2050
Wire Wire Line
	2900 1350 2900 2500
Wire Wire Line
	2550 1350 2900 1350
Wire Wire Line
	2550 1550 3100 1550
Wire Wire Line
	1650 2850 1650 4150
Wire Wire Line
	1650 4150 1950 4150
Wire Wire Line
	3750 4150 3750 2800
Wire Wire Line
	1950 2850 1950 4150
Connection ~ 1950 4150
Wire Wire Line
	2900 2800 2900 4150
Wire Wire Line
	1950 4150 2350 4150
Connection ~ 2900 4150
Wire Wire Line
	3400 2800 3400 4150
Wire Wire Line
	2900 4150 3400 4150
Connection ~ 3400 4150
Wire Wire Line
	3400 4150 3750 4150
$Comp
L power:Earth #PWR01
U 1 1 61CB7394
P 2350 4150
F 0 "#PWR01" H 2350 3900 50  0001 C CNN
F 1 "Earth" H 2350 4000 50  0001 C CNN
F 2 "" H 2350 4150 50  0001 C CNN
F 3 "~" H 2350 4150 50  0001 C CNN
	1    2350 4150
	1    0    0    -1  
$EndComp
Connection ~ 2350 4150
Wire Wire Line
	2350 4150 2900 4150
Wire Wire Line
	3350 900  2900 900 
Wire Wire Line
	2900 900  2900 1350
Connection ~ 2900 1350
Wire Wire Line
	5650 900  5650 950 
$Comp
L power:+5V #PWR04
U 1 1 61CB9175
P 4100 900
F 0 "#PWR04" H 4100 750 50  0001 C CNN
F 1 "+5V" H 4115 1073 50  0000 C CNN
F 2 "" H 4100 900 50  0001 C CNN
F 3 "" H 4100 900 50  0001 C CNN
	1    4100 900 
	1    0    0    -1  
$EndComp
Connection ~ 4100 900 
Wire Wire Line
	4100 900  4650 900 
$Comp
L Device:C C6
U 1 1 61CB957D
P 4650 1100
F 0 "C6" H 4765 1146 50  0000 L CNN
F 1 "4.7uF" H 4765 1055 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 4688 950 50  0001 C CNN
F 3 "~" H 4650 1100 50  0001 C CNN
	1    4650 1100
	1    0    0    -1  
$EndComp
$Comp
L Device:C C7
U 1 1 61CB96B1
P 5000 1100
F 0 "C7" H 5115 1146 50  0000 L CNN
F 1 "0.1uF" H 5115 1055 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 5038 950 50  0001 C CNN
F 3 "~" H 5000 1100 50  0001 C CNN
	1    5000 1100
	1    0    0    -1  
$EndComp
Wire Wire Line
	4650 950  4650 900 
Connection ~ 4650 900 
Wire Wire Line
	4650 900  5000 900 
Wire Wire Line
	5000 950  5000 900 
Connection ~ 5000 900 
Wire Wire Line
	5000 900  5650 900 
Wire Wire Line
	5000 1250 5000 1450
Wire Wire Line
	5000 1450 4700 1450
Wire Wire Line
	4700 1450 4700 3000
Wire Wire Line
	4650 1250 4650 1450
Wire Wire Line
	4650 1450 4700 1450
Connection ~ 4700 1450
$Comp
L power:Earth #PWR06
U 1 1 61CBB77A
P 4700 3000
F 0 "#PWR06" H 4700 2750 50  0001 C CNN
F 1 "Earth" H 4700 2850 50  0001 C CNN
F 2 "" H 4700 3000 50  0001 C CNN
F 3 "~" H 4700 3000 50  0001 C CNN
	1    4700 3000
	1    0    0    -1  
$EndComp
Wire Wire Line
	5050 950  5650 950 
Wire Wire Line
	5050 1850 4250 1850
Wire Wire Line
	5050 1950 4250 1950
Wire Wire Line
	4250 1950 4250 2050
$Comp
L Device:C C8
U 1 1 61CBEA08
P 5050 2650
F 0 "C8" H 5165 2696 50  0000 L CNN
F 1 "0.1uF" H 5165 2605 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 5088 2500 50  0001 C CNN
F 3 "~" H 5050 2650 50  0001 C CNN
	1    5050 2650
	1    0    0    -1  
$EndComp
Wire Wire Line
	4700 3000 5050 3000
Wire Wire Line
	5050 3000 5050 2800
Connection ~ 4700 3000
Wire Wire Line
	5050 3550 5050 3000
Connection ~ 5050 3000
Text GLabel 6350 1650 2    50   Input ~ 0
USBTXD
Text GLabel 6350 1750 2    50   Input ~ 0
USBRXD
Text GLabel 6350 1850 2    50   Input ~ 0
USBRTS
Text GLabel 6350 1950 2    50   Input ~ 0
USBCTS
Text GLabel 6350 2050 2    50   Input ~ 0
USBDTR
Text GLabel 6350 2150 2    50   Input ~ 0
USBDSR
Text GLabel 6350 2250 2    50   Input ~ 0
USBDCD
Text GLabel 6350 2350 2    50   Input ~ 0
USBRI
Text GLabel 6350 2850 2    50   Input ~ 0
SLEEP
$Comp
L Device:LED D1
U 1 1 61CC1F56
P 7550 1900
F 0 "D1" V 7589 1782 50  0000 R CNN
F 1 "RED RX" V 7500 2300 50  0000 R CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 7550 1900 50  0001 C CNN
F 3 "~" H 7550 1900 50  0001 C CNN
	1    7550 1900
	0    -1   -1   0   
$EndComp
$Comp
L Device:LED D2
U 1 1 61CC24C7
P 7900 1900
F 0 "D2" V 7939 1782 50  0000 R CNN
F 1 "BLUE TX" V 7848 1782 50  0000 R CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 7900 1900 50  0001 C CNN
F 3 "~" H 7900 1900 50  0001 C CNN
	1    7900 1900
	0    -1   -1   0   
$EndComp
$Comp
L Device:LED D3
U 1 1 61CC295D
P 8300 1900
F 0 "D3" V 8339 1782 50  0000 R CNN
F 1 "GREEN PWR" V 8248 1782 50  0000 R CNN
F 2 "LED_SMD:LED_0603_1608Metric" H 8300 1900 50  0001 C CNN
F 3 "~" H 8300 1900 50  0001 C CNN
	1    8300 1900
	0    -1   -1   0   
$EndComp
Wire Wire Line
	7900 1750 7900 1400
Wire Wire Line
	7900 1400 7750 1400
Wire Wire Line
	7550 1400 7550 1750
Wire Wire Line
	7550 2750 7550 2050
Wire Wire Line
	6350 2750 7550 2750
Wire Wire Line
	7900 2650 7900 2050
Wire Wire Line
	6350 2650 7900 2650
Wire Wire Line
	8300 2550 8300 2050
Wire Wire Line
	6350 2550 8300 2550
$Comp
L Device:R_US R4
U 1 1 61CCE211
P 7750 1050
F 0 "R4" H 7818 1096 50  0000 L CNN
F 1 "470R" H 7818 1005 50  0000 L CNN
F 2 "Resistor_SMD:R_0402_1005Metric" V 7790 1040 50  0001 C CNN
F 3 "~" H 7750 1050 50  0001 C CNN
	1    7750 1050
	1    0    0    -1  
$EndComp
$Comp
L Device:R_US R5
U 1 1 61CCE9E2
P 8300 1050
F 0 "R5" H 8368 1096 50  0000 L CNN
F 1 "470R" H 8368 1005 50  0000 L CNN
F 2 "Resistor_SMD:R_0402_1005Metric" V 8340 1040 50  0001 C CNN
F 3 "~" H 8300 1050 50  0001 C CNN
	1    8300 1050
	1    0    0    -1  
$EndComp
Wire Wire Line
	8300 1750 8300 1200
Wire Wire Line
	8300 750  7750 750 
Wire Wire Line
	7750 750  7750 650 
Wire Wire Line
	7750 750  7750 900 
Connection ~ 7750 750 
Wire Wire Line
	7750 1200 7750 1400
Connection ~ 7750 1400
Wire Wire Line
	7750 1400 7550 1400
Wire Wire Line
	8300 750  8300 900 
$Comp
L power:+5V #PWR08
U 1 1 61C99A2A
P 7750 650
F 0 "#PWR08" H 7750 500 50  0001 C CNN
F 1 "+5V" H 7765 823 50  0000 C CNN
F 2 "" H 7750 650 50  0001 C CNN
F 3 "" H 7750 650 50  0001 C CNN
	1    7750 650 
	1    0    0    -1  
$EndComp
$Comp
L USB-C-to-Serial-rescue:ZT213LEEA-SamacSys_Parts-USB-C-to-Serial-rescue IC1
U 1 1 61C9A54F
P 3950 5100
F 0 "IC1" H 4550 5365 50  0000 C CNN
F 1 "ZT213LEEA" H 4550 5274 50  0000 C CNN
F 2 "SamacSys_Parts:SOP65P780X200-28N" H 5000 5200 50  0001 L CNN
F 3 "" H 5000 5100 50  0001 L CNN
F 4 "Low Power 5V 250kbps RS232 Transceivers" H 5000 5000 50  0001 L CNN "Description"
F 5 "2" H 5000 4900 50  0001 L CNN "Height"
F 6 "ASIX" H 5000 4800 50  0001 L CNN "Manufacturer_Name"
F 7 "ZT213LEEA" H 5000 4700 50  0001 L CNN "Manufacturer_Part_Number"
F 8 "" H 5000 4600 50  0001 L CNN "Mouser Part Number"
F 9 "" H 5000 4500 50  0001 L CNN "Mouser Price/Stock"
F 10 "" H 5000 4400 50  0001 L CNN "Arrow Part Number"
F 11 "" H 5000 4300 50  0001 L CNN "Arrow Price/Stock"
	1    3950 5100
	1    0    0    -1  
$EndComp
Text GLabel 3950 5100 0    50   Input ~ 0
RTS
Text GLabel 3950 5200 0    50   Input ~ 0
TXD
NoConn ~ 3950 5300
NoConn ~ 3950 5600
Text GLabel 3950 5400 0    50   Input ~ 0
DSR
Text GLabel 3950 5500 0    50   Input ~ 0
USBDSR
Text GLabel 3950 5700 0    50   Input ~ 0
USBTXD
Text GLabel 3950 5800 0    50   Input ~ 0
USBDCD
Text GLabel 3950 5900 0    50   Input ~ 0
DCD
Text GLabel 5150 5100 2    50   Input ~ 0
DTR
Text GLabel 5150 5200 2    50   Input ~ 0
CTS
Text GLabel 5150 5300 2    50   Input ~ 0
USBCTS
Text GLabel 5150 5400 2    50   Input ~ 0
SLEEP
Text GLabel 5150 5600 2    50   Input ~ 0
RXD
Text GLabel 5150 5700 2    50   Input ~ 0
USBRXD
Text GLabel 5150 5800 2    50   Input ~ 0
USBDTR
Text GLabel 5150 5900 2    50   Input ~ 0
USBRTS
Text GLabel 5150 6000 2    50   Input ~ 0
USBRI
Text GLabel 5150 6100 2    50   Input ~ 0
RI
$Comp
L Device:C C9
U 1 1 61C9FF52
P 5250 6450
F 0 "C9" H 5365 6496 50  0000 L CNN
F 1 "0.1uF" H 5365 6405 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 5288 6300 50  0001 C CNN
F 3 "~" H 5250 6450 50  0001 C CNN
	1    5250 6450
	1    0    0    -1  
$EndComp
Wire Wire Line
	5250 6300 5150 6300
Wire Wire Line
	5150 6400 5150 6600
Wire Wire Line
	5150 6600 5250 6600
Text GLabel 5450 6200 2    50   Input ~ 0
V-
$Comp
L Device:C C10
U 1 1 61CA38E8
P 5300 6200
F 0 "C10" V 5150 6200 50  0000 C CNN
F 1 "0.1uF" V 5450 6200 50  0000 C CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 5338 6050 50  0001 C CNN
F 3 "~" H 5300 6200 50  0001 C CNN
	1    5300 6200
	0    1    1    0   
$EndComp
Wire Wire Line
	2900 6000 2900 6850
$Comp
L power:Earth #PWR02
U 1 1 61CA5FFB
P 2900 6850
F 0 "#PWR02" H 2900 6600 50  0001 C CNN
F 1 "Earth" H 2900 6700 50  0001 C CNN
F 2 "" H 2900 6850 50  0001 C CNN
F 3 "~" H 2900 6850 50  0001 C CNN
	1    2900 6850
	1    0    0    -1  
$EndComp
Text GLabel 2900 6550 2    50   Input ~ 0
V-
Text GLabel 5150 5500 2    50   Input ~ 0
EN
$Comp
L Device:C C3
U 1 1 61CA69AA
P 3500 6350
F 0 "C3" H 3615 6396 50  0000 L CNN
F 1 "0.1uF" H 3615 6305 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 3538 6200 50  0001 C CNN
F 3 "~" H 3500 6350 50  0001 C CNN
	1    3500 6350
	1    0    0    -1  
$EndComp
Wire Wire Line
	2900 6000 3950 6000
Wire Wire Line
	3950 6400 3950 6500
Wire Wire Line
	3500 6500 3950 6500
Wire Wire Line
	3500 6200 3950 6200
Text GLabel 3950 6300 0    50   Input ~ 0
V+
Text GLabel 3950 6100 0    50   Input ~ 0
VCC
Text GLabel 4550 4750 3    50   Input ~ 0
VCC
Text GLabel 4150 4950 2    50   Input ~ 0
V+
Text GLabel 3550 5150 3    50   Input ~ 0
EN
$Comp
L Device:C C5
U 1 1 61CB4977
P 4050 4750
F 0 "C5" H 4165 4796 50  0000 L CNN
F 1 "0.1uF" H 4165 4705 50  0000 L CNN
F 2 "Capacitor_SMD:C_0402_1005Metric" H 4088 4600 50  0001 C CNN
F 3 "~" H 4050 4750 50  0001 C CNN
	1    4050 4750
	1    0    0    -1  
$EndComp
Wire Wire Line
	4150 4950 4050 4950
Wire Wire Line
	4050 4950 4050 4900
Wire Wire Line
	4050 4400 3550 4400
Wire Wire Line
	3550 4400 3550 5150
Wire Wire Line
	4050 4600 4050 4400
Wire Wire Line
	4050 4400 4550 4400
Wire Wire Line
	4550 4400 4550 4750
Connection ~ 4050 4400
$Comp
L power:+5V #PWR05
U 1 1 61CB89B1
P 4550 4400
F 0 "#PWR05" H 4550 4250 50  0001 C CNN
F 1 "+5V" H 4565 4573 50  0000 C CNN
F 2 "" H 4550 4400 50  0001 C CNN
F 3 "" H 4550 4400 50  0001 C CNN
	1    4550 4400
	1    0    0    -1  
$EndComp
Connection ~ 4550 4400
Wire Wire Line
	5050 3550 5650 3550
Wire Wire Line
	5050 950  5050 1650
$Comp
L SamacSys_Parts:FT231XS-R IC2
U 1 1 61CBA920
P 5050 1650
F 0 "IC2" H 5700 2531 50  0000 C CNN
F 1 "FT231XS-R" H 5700 2440 50  0000 C CNN
F 2 "SamacSys_Parts:SOP64P599X175-20N" H 6200 2150 50  0001 L CNN
F 3 "https://datasheet.datasheetarchive.com/originals/distributors/Datasheets_SAMA/824938d1687833d6997706543241551a.pdf" H 6200 2050 50  0001 L CNN
F 4 "FTDI Chip FT231XS-R, Interface RS232, RS422, RS485, SIE, UART 3MBd, 5 V, 20-pin, SSOP" H 6200 1950 50  0001 L CNN "Description"
F 5 "1.753" H 6200 1850 50  0001 L CNN "Height"
F 6 "FTDI Chip" H 6200 1750 50  0001 L CNN "Manufacturer_Name"
F 7 "FT231XS-R" H 6200 1650 50  0001 L CNN "Manufacturer_Part_Number"
F 8 "895-FT231XS-R" H 6200 1550 50  0001 L CNN "Mouser Part Number"
F 9 "https://www.mouser.co.uk/ProductDetail/FTDI/FT231XS-R?qs=Gp1Yz1mis3WduRPsgrTbtg%3D%3D" H 6200 1450 50  0001 L CNN "Mouser Price/Stock"
F 10 "FT231XS-R" H 6200 1350 50  0001 L CNN "Arrow Part Number"
F 11 "https://www.arrow.com/en/products/ft231xs-r/ftdi-chip?region=nac" H 6200 1250 50  0001 L CNN "Arrow Price/Stock"
	1    5050 1650
	1    0    0    -1  
$EndComp
Wire Wire Line
	5050 2150 5050 2500
Connection ~ 5650 950 
Text GLabel 5050 2150 0    50   Input ~ 0
RESET#
Text GLabel 5050 1650 0    50   Input ~ 0
RESET#
Text GLabel 7750 4850 0    50   Input ~ 0
DCD
Text GLabel 7750 5050 0    50   Input ~ 0
RXD
Text GLabel 7750 5250 0    50   Input ~ 0
TXD
Text GLabel 7750 5450 0    50   Input ~ 0
DTR
Text GLabel 8750 4950 2    50   Input ~ 0
DSR
Text GLabel 8750 5150 2    50   Input ~ 0
RTS
Text GLabel 8750 5350 2    50   Input ~ 0
CTS
Text GLabel 8750 5550 2    50   Input ~ 0
RI
$Comp
L power:Earth #PWR07
U 1 1 61CC1272
P 7750 5750
F 0 "#PWR07" H 7750 5500 50  0001 C CNN
F 1 "Earth" H 7750 5600 50  0001 C CNN
F 2 "" H 7750 5750 50  0001 C CNN
F 3 "~" H 7750 5750 50  0001 C CNN
	1    7750 5750
	1    0    0    -1  
$EndComp
Wire Wire Line
	7750 5650 7750 5750
$Comp
L SamacSys_Parts:MPZ1608S221ATA00 FB1
U 1 1 61CD2C5B
P 3350 900
F 0 "FB1" V 3688 672 50  0000 R CNN
F 1 "2A 220 OHM" V 3597 672 50  0000 R CNN
F 2 "SamacSys_Parts:BEADC1608X75N" H 4000 1000 50  0001 L CNN
F 3 "https://product.tdk.com/system/files/dam/doc/product/emc/emc/beads/catalog/beads_commercial_power_mpz1608_en.pdf" H 4000 900 50  0001 L CNN
F 4 "220 Ohms @ 100MHz 1 Power Line Ferrite Bead 0603 (1608 Metric) 2.2A 50mOhm" H 4000 800 50  0001 L CNN "Description"
F 5 "0.75" H 4000 700 50  0001 L CNN "Height"
F 6 "TDK" H 4000 600 50  0001 L CNN "Manufacturer_Name"
F 7 "MPZ1608S221ATA00" H 4000 500 50  0001 L CNN "Manufacturer_Part_Number"
F 8 "810-MPZ1608S221ATA00" H 4000 400 50  0001 L CNN "Mouser Part Number"
F 9 "https://www.mouser.co.uk/ProductDetail/TDK/MPZ1608S221ATA00?qs=pLY5GE0xrmLZeKkazChaNg%3D%3D" H 4000 300 50  0001 L CNN "Mouser Price/Stock"
F 10 "MPZ1608S221ATA00" H 4000 200 50  0001 L CNN "Arrow Part Number"
F 11 "https://www.arrow.com/en/products/mpz1608s221ata00/tdk?region=nac" H 4000 100 50  0001 L CNN "Arrow Price/Stock"
	1    3350 900 
	0    -1   -1   0   
$EndComp
Wire Wire Line
	3450 900  4100 900 
$Comp
L USB-C-to-Serial-rescue:5747844-4-5747844-4-USB-C-to-Serial-rescue J1
U 1 1 61C9B9A4
P 8250 5250
F 0 "J1" H 8250 6017 50  0000 C CNN
F 1 "5747844-4" H 8250 5926 50  0000 C CNN
F 2 "3-338168-2:33381682" H 8250 5250 50  0001 L BNN
F 3 "" H 8250 5250 50  0001 L BNN
F 4 "Gold" H 8250 5250 50  0001 L BNN "FINISH"
F 5 "" H 8250 5250 50  0001 L BNN "CONNECTOR"
F 6 "" H 8250 5250 50  0001 L BNN "SIGNAL_INTEGRITY"
F 7 "MANUFACTURER RECOMMENDATIONS" H 8250 5250 50  0001 L BNN "STANDARD"
F 8 "Receptacle" H 8250 5250 50  0001 L BNN "TYPE"
F 9 "" H 8250 5250 50  0001 L BNN "FOOTPRINT_REFERENCE"
F 10 "TE Connectivity" H 8250 5250 50  0001 L BNN "MANUFACTURER"
F 11 "" H 8250 5250 50  0001 L BNN "CASE"
F 12 "" H 8250 5250 50  0001 L BNN "APPLICATION"
F 13 "" H 8250 5250 50  0001 L BNN "SPICE_MODEL"
F 14 "Amplimite HD-20" H 8250 5250 50  0001 L BNN "SERIES"
F 15 "" H 8250 5250 50  0001 L BNN "LIBRARY_REF"
F 16 "yes" H 8250 5250 50  0001 L BNN "ROHS_COMPLIANT"
F 17 "" H 8250 5250 50  0001 L BNN "INSULATION_RESISTANCE"
F 18 "" H 8250 5250 50  0001 L BNN "PUBLISHER"
F 19 "125V" H 8250 5250 50  0001 L BNN "VOLTAGE_RATING_AC"
F 20 "" H 8250 5250 50  0001 L BNN "GENDER"
F 21 "Through Hole" H 8250 5250 50  0001 L BNN "TECHNOLOGY"
F 22 "" H 8250 5250 50  0001 L BNN "PUBLISHED"
F 23 "Right Angle" H 8250 5250 50  0001 L BNN "ORIENTATION"
F 24 "DUAL ROW" H 8250 5250 50  0001 L BNN "CONFIGURATION"
F 25 "CONN D-SUB RCPT 9POS R/A SOLDER" H 8250 5250 50  0001 L BNN "PART_DESCRIPTION"
F 26 "http://www.te.com/commerce/DocumentDelivery/DDEController?Action=srchrtrv&DocNm=5747844&DocType=Customer+Drawing&DocLang=English" H 8250 5250 50  0001 L BNN "MANUFACTURER_LINK"
F 27 "6A" H 8250 5250 50  0001 L BNN "CURRENT_RATING"
F 28 "" H 8250 5250 50  0001 L BNN "FOOTPRINT"
F 29 "Revised per ECO-12-004835" H 8250 5250 50  0001 L BNN "LATEST_REVISION_NOTE"
F 30 "2.74mm" H 8250 5250 50  0001 L BNN "PITCH"
F 31 "P" H 8250 5250 50  0001 L BNN "PART_REV"
F 32 "9" H 8250 5250 50  0001 L BNN "POSITIONS"
F 33 "" H 8250 5250 50  0001 L BNN "LIBRARY_PATH"
F 34 "" H 8250 5250 50  0001 L BNN "VOLTAGE_RATING_DC"
F 35 "" H 8250 5250 50  0001 L BNN "FOOTPRINT_PATH"
F 36 "" H 8250 5250 50  0001 L BNN "DESIGNATOR"
F 37 "11MAR11" H 8250 5250 50  0001 L BNN "LATEST_REVISION_DATE"
F 38 "" H 8250 5250 50  0001 L BNN "PACKAGE"
	1    8250 5250
	1    0    0    -1  
$EndComp
$Comp
L power:Earth #PWR09
U 1 1 61CB3CA5
P 8750 5850
F 0 "#PWR09" H 8750 5600 50  0001 C CNN
F 1 "Earth" H 8750 5700 50  0001 C CNN
F 2 "" H 8750 5850 50  0001 C CNN
F 3 "~" H 8750 5850 50  0001 C CNN
	1    8750 5850
	1    0    0    -1  
$EndComp
Text GLabel 4400 1850 1    50   Input ~ 0
D-
Text GLabel 4400 1950 3    50   Input ~ 0
D+
Text GLabel 3050 2050 3    50   Input ~ 0
DD+
Text GLabel 3150 1850 1    50   Input ~ 0
DD-
$EndSCHEMATC
